import java.util.ArrayList;
public interface Shape {
    double  pi = 3.14;
    double calcArea(ArrayList<Double> dimensions);
    double calcPerm(ArrayList<Double> dimensions);
}
